package com.wiley.BlogManagementSystem.model;

public class Blog_Tag {
}
