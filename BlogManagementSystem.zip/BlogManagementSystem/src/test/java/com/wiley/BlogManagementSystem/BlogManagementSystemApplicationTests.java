package com.wiley.BlogManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
